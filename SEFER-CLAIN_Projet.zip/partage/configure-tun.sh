#! /bin/bash

ip addr add $1 dev tun0
